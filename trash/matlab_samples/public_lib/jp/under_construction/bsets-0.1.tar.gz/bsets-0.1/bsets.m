function s = bsets(X,q,alpha,beta)
% s = bsets(X,q,alpha,beta)
% Bayesian Sets (Ghahramani and Heller, 2005) implementation.
% X : binary sparse matrix of (features * entries)
% q : row vector of query indexes
% s : row vector of scores for each entry in X
% alpha,beta : Beta hyperparameters of prior distribution (column vectors)
% $Id: bsets.m,v 1.2 2006/02/13 13:54:02 dmochiha Exp $
n = length(q);
c = sum(X(:,q),2);
w = log(1 + c ./ alpha) - log(1 + (n - c) ./ beta);
s = w' * X;
% end of file.
