function [alpha,beta] = bsparam(X,c)
% [alpha,beta] = bsparam(X,c)
% Bayesian Sets (Ghahramani and Heller, 2005) simple parameter generator.
% X : binary sparse matrix of (features * entries)
% c : Dirichlet concentration parameter (usually, c = 2)
% Sat Jan 28 16:38:26 JST 2006 dmochiha@slc.atr.jp
% $Id: bsparam.m,v 1.2 2006/02/13 13:53:31 dmochiha Exp $
n = size(X,2);
m = full(sum(X,2)) / n;
alpha = c * m;
beta  = c * (1 - m);
% end of file.
