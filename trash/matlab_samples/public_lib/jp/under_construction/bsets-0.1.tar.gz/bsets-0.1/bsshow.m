function bsshow(s,file,n)
% bsshow(s,file,[n])
% Bayesian Sets (Ghahramani and Heller, 2005) retrieval viewer.
% s    : row vector of scores for each entry, retuned from bsets()
% file : text file, each line corresponds to each dimension of s
% n    : number of results to show (default 20)
% $Id: bsshow.m,v 1.2 2006/02/13 13:54:16 dmochiha Exp $
if nargin < 3
  n = 20;
end
l = length(s);
t = strload(file);
[y,idx] = sort(s);
for i = 1:n
  x = idx(l-i+1);
  fprintf('%d\t%g\t%s\n', x, s(x), t{x});
end
