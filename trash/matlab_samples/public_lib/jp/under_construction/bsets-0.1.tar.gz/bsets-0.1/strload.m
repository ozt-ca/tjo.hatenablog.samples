function c = strload(file)
% c = strload(file)
% creates a cell array of string from file.
% file : string of file name.
% $Id: strload.m,v 1.1 2004/10/01 03:59:56 dmochiha Exp $

% preallocate
l = wcl(file);
c = cell(1,floor(l * 3 / 4));
% open file
fid = fopen(file,'r');
if (fid == -1)
  error(sprintf('cellload: can''t open %s.\n',file));
end
% read file
n = 0;
while ~feof(fid)
  l = fgetl(fid);
  if length(l) > 0  % skip blank lines
    n = n + 1;
    c{n} = l;
  end
end
% close file
fclose(fid);

% check
if (size(c,2) > n)
  newc = cell(1,n);
  newc(1:n) = c(1:n);
  c = newc;
end

% end of file.
