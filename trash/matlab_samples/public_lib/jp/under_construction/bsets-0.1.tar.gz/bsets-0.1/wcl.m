function n = wcl(file)
% n = wcl(file)
% "wc -l" function in MATLAB.
% file is assumed data, so empty lines are ignored considering fscanf().
% Fri Feb 13 17:43:16 2004 JST daichi.mochihashi@atr.jp

% open file
fid = fopen(file,'r');
if (fid == -1)
  error(sprintf('wcl: can''t open %s.\n',file));
end
% read lines
n = 0;
while ~feof(fid)
  l = fgetl(fid);
  if length(l) > 0
    n = n + 1;
  end
end
% close file
fclose(fid);
